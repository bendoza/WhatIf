import React from 'react';

const TestComponent = () => {
  return (
    <div>
      <h1 className="text-6xl">Test Heading 1</h1>
      <h2>Test Heading 2</h2>
    </div>
  );
};

export default TestComponent;
